import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, Application, InterviewSession } from '@/lib/supabase';
import { Button, Card, ScoreRing } from '@/components/ui';
import { AlertTriangle, ArrowLeft, ShieldAlert, Send, CheckCircle2, Camera, CameraOff } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  category: string;
}

export default function InterviewView({
  application,
  onComplete,
  onExit,
}: {
  application: Application;
  onComplete: () => void;
  onExit: () => void;
}) {
  const { user } = useAuth();
  const [session, setSession] = useState<InterviewSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentQ, setCurrentQ] = useState(0);
  const [answer, setAnswer] = useState('');
  const [answers, setAnswers] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [finalScore, setFinalScore] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string>('');
  const [warning, setWarning] = useState<string | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [cameraOn, setCameraOn] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const pasteAttempts = useRef(0);

  // Anti-cheat: detect tab visibility / leave
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && session && !showResults) {
        restartInterview();
      }
    };
    const handleBlur = () => {
      if (session && !showResults && !submitting) {
        restartInterview();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('blur', handleBlur);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('blur', handleBlur);
    };
  }, [session, showResults, submitting]);

  // Anti-cheat: block paste
  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    pasteAttempts.current += 1;
    setWarning(`Coller n'est pas autorisé. Tentative ${pasteAttempts.current} enregistrée.`);
    setTimeout(() => setWarning(null), 3000);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setCameraOn(true);
    } catch {
      setWarning('Caméra indisponible. L\'entretien continue sans vidéo.');
      setTimeout(() => setWarning(null), 3000);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraOn(false);
  };

  const restartInterview = async () => {
    if (!user || !session) return;
    setWarning('Vous avez quitté la page. L\'entretien redémarre.');
    stopCamera();
    setTimeout(() => setWarning(null), 4000);
    await supabase.from('interview_sessions').update({
      answers: [],
      scores: [],
      completed: false,
      restart_count: (session.restart_count || 0) + 1,
    }).eq('id', session.id);
    setCurrentQ(0);
    setAnswer('');
    setAnswers([]);
    setShowResults(false);
    setSession({ ...session, answers: [], scores: [], completed: false, restart_count: (session.restart_count || 0) + 1 });
  };

  useEffect(() => {
    initInterview();
    return () => stopCamera();
  }, []);

  const initInterview = async () => {
    if (!user) return;
    setLoading(true);
    const { data: existing } = await supabase
      .from('interview_sessions')
      .select('*')
      .eq('application_id', application.id)
      .eq('candidate_id', user.id)
      .order('started_at', { ascending: false })
      .maybeSingle();

    let sess: InterviewSession | null = existing as InterviewSession;

    if (!sess) {
      const { data: newSess } = await supabase.from('interview_sessions').insert({
        application_id: application.id,
        candidate_id: user.id,
        questions: [],
        answers: [],
        scores: [],
      }).select().single();
      sess = newSess as InterviewSession;
    }

    if (sess) {
      setSession(sess);
      if (sess.answers && sess.answers.length > 0) {
        setAnswers(sess.answers);
        setCurrentQ(Math.min(sess.answers.length, 4));
      }
    }

    // Fetch questions from edge function
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/interview-questions`;
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ jobPosition: application.job_position }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.questions) setQuestions(data.questions);
      }
    } catch {
      // fallback questions
      setQuestions([
        { id: 1, question: `Présentez-vous et expliquez pourquoi vous postulez au poste de ${application.job_position}.`, category: 'Présentation' },
        { id: 2, question: 'Décrivez une expérience professionnelle pertinente pour ce poste.', category: 'Expérience' },
        { id: 3, question: 'Quelles sont vos principales compétences techniques pour ce poste ?', category: 'Compétences' },
        { id: 4, question: 'Comment gérez-vous une situation de conflit dans une équipe ?', category: 'Soft skills' },
        { id: 5, question: 'Où vous voyez-vous dans 3 ans et comment ce poste s\'inscrit-il dans votre projet ?', category: 'Motivation' },
      ]);
    }

    await supabase.from('applications').update({ status: 'interviewing' }).eq('id', application.id);
    setLoading(false);
  };

  const submitAnswer = async () => {
    if (!answer.trim() || !session || !user) return;
    setSubmitting(true);
    const newAnswers = [...answers, answer.trim()];
    setAnswers(newAnswers);

    const { data: updated } = await supabase.from('interview_sessions').update({
      answers: newAnswers,
    }).eq('id', session.id).select().single();

    setSession(updated as InterviewSession);
    setAnswer('');
    setCurrentQ(currentQ + 1);
    setSubmitting(false);

    if (currentQ + 1 >= questions.length) {
      await finishInterview(newAnswers);
    }
  };

  const finishInterview = async (allAnswers: string[]) => {
    setSubmitting(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/interview-evaluate`;
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobPosition: application.job_position,
          questions: questions.map((q) => q.question),
          answers: allAnswers,
        }),
      });
      if (!res.ok) throw new Error('Eval failed');
      const data = await res.json();
      const score = data.score ?? 60;
      const fb = data.feedback ?? '';
      const perQ = data.scores ?? [];

      await supabase.from('interview_sessions').update({
        completed: true,
        total_score: score,
        scores: perQ,
        completed_at: new Date().toISOString(),
      }).eq('id', session!.id);

      await supabase.from('applications').update({
        status: 'evaluating',
        score,
        ai_feedback: fb,
      }).eq('id', application.id);

      setFinalScore(score);
      setFeedback(fb);
      setShowResults(true);
      stopCamera();
    } catch {
      const fallbackScore = 60;
      await supabase.from('interview_sessions').update({
        completed: true,
        total_score: fallbackScore,
        completed_at: new Date().toISOString(),
      }).eq('id', session!.id);
      await supabase.from('applications').update({
        status: 'evaluating',
        score: fallbackScore,
      }).eq('id', application.id);
      setFinalScore(fallbackScore);
      setFeedback('Évaluation terminée. Le recruteur examinera votre profil prochainement.');
      setShowResults(true);
      stopCamera();
    }
    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="h-12 w-12 border-3 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-600 font-medium">Préparation de l'entretien...</p>
        </div>
      </div>
    );
  }

  if (showResults) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <Card className="max-w-lg w-full p-8 text-center">
          <div className="h-16 w-16 rounded-2xl bg-emerald-50 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 size={32} className="text-emerald-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Entretien terminé !</h2>
          <p className="text-slate-500 mb-6">Votre entretien a été soumis à l'évaluation. Votre candidature est désormais en cours d'évaluation.</p>

          <div className="flex flex-col items-center gap-3 mb-6">
            <ScoreRing score={finalScore} size={120} />
            <p className="text-sm font-semibold text-slate-700">Score global</p>
          </div>

          {feedback && (
            <div className="p-4 bg-slate-50 rounded-xl text-left mb-6">
              <p className="text-xs font-semibold text-slate-700 mb-1">Retour de l'IA</p>
              <p className="text-sm text-slate-600 leading-relaxed">{feedback}</p>
            </div>
          )}

          <Button onClick={onComplete} size="lg" className="w-full">
            Retour à mon espace
          </Button>
        </Card>
      </div>
    );
  }

  const q = questions[currentQ];
  const progress = ((currentQ) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between sticky top-0 z-30">
        <button onClick={onExit} className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-800">
          <ArrowLeft size={18} /> Quitter
        </button>
        <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 bg-amber-50 px-3 py-1.5 rounded-full">
          <ShieldAlert size={14} /> Mode anti-triche actif
        </div>
        <div className="text-sm text-slate-500">Question {currentQ + 1} / {questions.length}</div>
      </header>

      {/* Progress bar */}
      <div className="h-1 bg-slate-200">
        <div className="h-full bg-teal-500 transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>

      {warning && (
        <div className="bg-red-50 border-b border-red-200 px-6 py-2.5 flex items-center gap-2 text-sm text-red-700">
          <AlertTriangle size={16} className="flex-shrink-0" />
          {warning}
        </div>
      )}

      <div className="flex-1 flex">
        {/* Main area */}
        <div className="flex-1 p-6 lg:p-10 max-w-3xl mx-auto w-full">
          {q && (
            <>
              <div className="mb-2">
                <span className="inline-block px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-semibold mb-3">
                  {q.category}
                </span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-6 leading-snug">{q.question}</h2>

              <div className="mb-4">
                <textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  onPaste={handlePaste}
                  placeholder="Rédigez votre réponse ici... (le copier-coller est désactivé)"
                  rows={8}
                  className="w-full px-5 py-4 rounded-2xl border-2 border-slate-200 bg-white text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500 transition-all resize-none text-sm leading-relaxed no-select"
                  autoFocus
                />
                <p className="text-xs text-slate-400 mt-2">
                  {answer.length} caractères — minimum recommandé : 100
                </p>
              </div>

              <Button
                onClick={submitAnswer}
                size="lg"
                className="w-full"
                disabled={submitting || answer.trim().length < 20}
              >
                {submitting ? (
                  'Évaluation...'
                ) : currentQ + 1 >= questions.length ? (
                  <><Send size={18} /> Terminer l'entretien</>
                ) : (
                  <><Send size={18} /> Question suivante</>
                )}
              </Button>
            </>
          )}
        </div>

        {/* Camera sidebar */}
        <div className="hidden lg:flex w-72 bg-slate-900 flex-col items-center justify-center p-6">
          <div className="text-center mb-4">
            <p className="text-white text-sm font-semibold mb-1">Surveillance caméra</p>
            <p className="text-slate-400 text-xs">Restez visible pendant l'entretien</p>
          </div>
          <div className="relative w-full aspect-video bg-slate-800 rounded-xl overflow-hidden mb-4">
            {cameraOn ? (
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            ) : (
              <div className="flex items-center justify-center h-full text-slate-500">
                <CameraOff size={32} />
              </div>
            )}
          </div>
          {cameraOn ? (
            <Button variant="secondary" size="sm" onClick={stopCamera} className="w-full">
              <CameraOff size={16} /> Désactiver
            </Button>
          ) : (
            <Button variant="secondary" size="sm" onClick={startCamera} className="w-full">
              <Camera size={16} /> Activer la caméra
            </Button>
          )}
          <div className="mt-6 space-y-2 text-xs text-slate-400">
            <p className="flex items-center gap-2"><ShieldAlert size={12} /> Quitter la page = redémarrage</p>
            <p className="flex items-center gap-2"><ShieldAlert size={12} /> Copier-coller = interdit</p>
          </div>
        </div>
      </div>
    </div>
  );
}
