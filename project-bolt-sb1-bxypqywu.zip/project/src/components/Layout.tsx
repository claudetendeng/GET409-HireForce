import { ReactNode, useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Logo, Avatar } from '@/components/ui';
import { LogOut, Bell } from 'lucide-react';
import { supabase, Notification } from '@/lib/supabase';
import Chatbot from '@/components/Chatbot';

interface NavItem {
  id: string;
  label: string;
  icon: ReactNode;
}

export default function Layout({
  children,
  navItems,
  activeNav,
  onNavChange,
}: {
  children: ReactNode;
  navItems: NavItem[];
  activeNav: string;
  onNavChange: (id: string) => void;
}) {
  const { profile, signOut } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifs, setShowNotifs] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const loadNotifs = async () => {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(10);
      if (data) setNotifications(data as Notification[]);
    };
    loadNotifs();
    const channel = supabase
      .channel('notifications')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${profile.id}` }, () => loadNotifs())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [profile]);

  const unreadCount = notifications.filter((n) => !n.read).length;
  const activeItem = navItems.find((n) => n.id === activeNav);

  const markAllRead = async () => {
    if (!profile) return;
    await supabase.from('notifications').update({ read: true }).eq('user_id', profile.id).eq('read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col fixed h-screen z-40">
        <div className="p-5 border-b border-slate-100">
          <Logo />
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                activeNav === item.id
                  ? 'bg-teal-50 text-teal-700'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-slate-100">
          <div className="flex items-center gap-3 p-2">
            <Avatar url={profile?.avatar_url} name={profile?.full_name || 'U'} size={36} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-900 truncate">{profile?.full_name}</p>
              <p className="text-xs text-slate-500 truncate">{profile?.email}</p>
            </div>
            <button onClick={signOut} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-red-600 transition-colors" title="Déconnexion">
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-30">
          <h1 className="text-lg font-bold text-slate-900">{activeItem?.label}</h1>
          <div className="flex items-center gap-2">
            <div className="relative">
              <button
                onClick={() => { setShowNotifs(!showNotifs); if (!showNotifs && unreadCount > 0) markAllRead(); }}
                className="relative p-2 rounded-lg hover:bg-slate-100 text-slate-600"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>
              {showNotifs && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 max-h-96 overflow-y-auto">
                  <div className="p-3 border-b border-slate-100 font-semibold text-sm text-slate-700">Notifications</div>
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-sm text-slate-400">Aucune notification</div>
                  ) : (
                    notifications.map((n) => (
                      <div key={n.id} className="p-3 border-b border-slate-50 hover:bg-slate-50">
                        <p className="text-sm font-medium text-slate-800">{n.title}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{n.message}</p>
                        <p className="text-[11px] text-slate-400 mt-1">{new Date(n.created_at).toLocaleString('fr-FR')}</p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 px-2">
              <Avatar url={profile?.avatar_url} name={profile?.full_name || 'U'} size={32} />
              <span className="text-sm font-medium text-slate-700 hidden sm:block">{profile?.full_name}</span>
            </div>
          </div>
        </header>
        <main className="p-6 lg:p-8 max-w-7xl mx-auto">{children}</main>
      </div>
      <Chatbot />
    </div>
  );
}
