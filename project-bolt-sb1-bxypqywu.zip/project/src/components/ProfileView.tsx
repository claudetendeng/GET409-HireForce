import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, Button, Input, Avatar } from '@/components/ui';
import { Camera, Save } from 'lucide-react';

export default function ProfileView() {
  const { user, profile, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url || null);
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0] || !user) return;
    setUploadingAvatar(true);
    try {
      const file = e.target.files[0];
      const ext = file.name.split('.').pop();
      const path = `${user.id}/avatar.${ext}`;
      const { error } = await supabase.storage.from('avatars').upload(path, file, { upsert: true });
      if (error) throw error;
      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path);
      setAvatarUrl(publicUrl);
    } catch {
      alert('Erreur lors du téléversement de la photo.');
    }
    setUploadingAvatar(false);
  };

  const save = async () => {
    if (!user) return;
    setSaving(true);
    await supabase.from('profiles').update({
      full_name: fullName,
      avatar_url: avatarUrl,
    }).eq('id', user.id);
    await refreshProfile();
    setSaving(false);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="p-8">
        <h2 className="text-xl font-bold text-slate-900 mb-6">Mon profil</h2>

        <div className="flex items-center gap-4 mb-8">
          <div className="relative">
            <Avatar url={avatarUrl} name={fullName || 'U'} size={80} />
            <label className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-teal-600 hover:bg-teal-700 text-white flex items-center justify-center cursor-pointer shadow-lg">
              <Camera size={14} />
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
            </label>
          </div>
          <div>
            <p className="font-bold text-slate-900 text-lg">{fullName || 'Votre nom'}</p>
            <p className="text-sm text-slate-500">{profile?.email}</p>
            <p className="text-xs text-teal-600 font-semibold mt-1 capitalize">{profile?.role === 'recruiter' ? 'Recruteur' : 'Candidat'}</p>
          </div>
        </div>

        {uploadingAvatar && <p className="text-xs text-slate-400 mb-4">Téléversement de la photo...</p>}

        <div className="space-y-4">
          <Input label="Nom complet" value={fullName} onChange={setFullName} placeholder="Votre nom" />
          <Input label="Adresse email" value={profile?.email || ''} onChange={() => {}} />
          <p className="text-xs text-slate-400 -mt-2">L'email ne peut pas être modifié.</p>
        </div>

        <div className="mt-6">
          <Button onClick={save} disabled={saving || uploadingAvatar}>
            <Save size={18} /> {saving ? 'Sauvegarde...' : 'Enregistrer'}
          </Button>
        </div>
      </Card>
    </div>
  );
}
