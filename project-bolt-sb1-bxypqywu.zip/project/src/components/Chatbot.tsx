import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, ChatMessage } from '@/lib/supabase';
import { MessageSquare, X, Send, Bot } from 'lucide-react';
import { Avatar } from '@/components/ui';

export default function Chatbot() {
  const { user, profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open && user && messages.length === 0) {
      loadHistory();
    }
  }, [open, user]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const loadHistory = async () => {
    setLoadingHistory(true);
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', user!.id)
      .order('created_at', { ascending: true })
      .limit(50);
    if (data && data.length > 0) {
      setMessages(data as ChatMessage[]);
    } else {
      const greeting: ChatMessage = {
        id: 'greeting',
        user_id: user!.id,
        role: 'assistant',
        content: profile?.role === 'recruiter'
          ? "Bonjour ! Je suis votre assistant SmartRecrut. Je peux vous aider à analyser les candidats, comprendre les scores, planifier des entretiens et gérer votre recrutement. Comment puis-je vous aider ?"
          : "Bonjour ! Je suis votre assistant SmartRecrut. Je peux vous guider dans votre candidature, préparer votre entretien IA, et répondre à vos questions sur le processus de recrutement. Comment puis-je vous aider ?",
        created_at: new Date().toISOString(),
      };
      setMessages([greeting]);
    }
    setLoadingHistory(false);
  };

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setLoading(true);

    const tempUserMsg: ChatMessage = {
      id: 'temp-' + Date.now(),
      user_id: user!.id,
      role: 'user',
      content: userMsg,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);

    await supabase.from('chat_messages').insert({
      user_id: user!.id,
      role: 'user',
      content: userMsg,
    });

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chatbot`;
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userMsg, role: profile?.role || 'candidate' }),
      });
      if (!res.ok) throw new Error('Chat error');
      const data = await res.json();
      const reply = data.reply || "Désolé, je n'ai pas pu traiter votre demande.";

      const assistantMsg: ChatMessage = {
        id: 'temp-a-' + Date.now(),
        user_id: user!.id,
        role: 'assistant',
        content: reply,
        created_at: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMsg]);

      await supabase.from('chat_messages').insert({
        user_id: user!.id,
        role: 'assistant',
        content: reply,
      });
    } catch {
      const fallback = "Je rencontre un problème technique. Réessayez dans un instant.";
      setMessages((prev) => [...prev, {
        id: 'err-' + Date.now(),
        user_id: user!.id,
        role: 'assistant',
        content: fallback,
        created_at: new Date().toISOString(),
      }]);
    }
    setLoading(false);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-teal-600 hover:bg-teal-700 text-white shadow-xl shadow-teal-600/40 flex items-center justify-center transition-all hover:scale-105"
        aria-label="Chatbot"
      >
        {open ? <X size={24} /> : <MessageSquare size={24} />}
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-[calc(100vw-3rem)] max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col" style={{ height: '32rem' }}>
          <div className="flex items-center gap-3 p-4 border-b border-slate-100">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
              <Bot size={20} className="text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 text-sm">Assistant SmartRecrut</h3>
              <p className="text-xs text-emerald-600 flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" /> En ligne
              </p>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-hide">
            {loadingHistory ? (
              <div className="flex items-center justify-center h-full">
                <div className="h-8 w-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (
              messages.map((m) => (
                <div key={m.id} className={`flex gap-2 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  {m.role === 'assistant' && (
                    <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center flex-shrink-0">
                      <Bot size={16} className="text-white" />
                    </div>
                  )}
                  {m.role === 'user' && (
                    <Avatar url={profile?.avatar_url} name={profile?.full_name || 'U'} size={32} />
                  )}
                  <div
                    className={`max-w-[75%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-teal-600 text-white rounded-tr-sm'
                        : 'bg-slate-100 text-slate-800 rounded-tl-sm'
                    }`}
                  >
                    {m.content}
                  </div>
                </div>
              ))
            )}
            {loading && (
              <div className="flex gap-2">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
                  <Bot size={16} className="text-white" />
                </div>
                <div className="bg-slate-100 px-4 py-3 rounded-2xl rounded-tl-sm">
                  <div className="flex gap-1">
                    <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t border-slate-100 flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder="Posez votre question..."
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500"
              disabled={loading}
            />
            <button
              onClick={send}
              disabled={loading || !input.trim()}
              className="h-10 w-10 rounded-xl bg-teal-600 hover:bg-teal-700 text-white flex items-center justify-center disabled:opacity-50 transition-colors"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
