import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type UserRole = 'candidate' | 'recruiter';

export type ApplicationStatus =
  | 'pending'
  | 'interviewing'
  | 'evaluating'
  | 'scheduled'
  | 'refused'
  | 'recruited';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  role: UserRole;
  created_at: string;
}

export interface Application {
  id: string;
  candidate_id: string;
  job_position: string;
  cv_url: string | null;
  cv_text: string | null;
  status: ApplicationStatus;
  score: number | null;
  ai_feedback: string | null;
  created_at: string;
  updated_at: string;
  profiles?: Profile;
}

export interface InterviewSession {
  id: string;
  application_id: string;
  candidate_id: string;
  questions: string[];
  answers: string[];
  scores: number[];
  total_score: number | null;
  completed: boolean;
  started_at: string;
  completed_at: string | null;
  restart_count: number;
}

export interface ScheduledInterview {
  id: string;
  application_id: string;
  candidate_id: string;
  recruiter_id: string;
  scheduled_date: string;
  instructions: string;
  location: string;
  status: 'pending' | 'completed' | 'cancelled';
  created_at: string;
  applications?: Application;
  profiles?: Profile;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}
