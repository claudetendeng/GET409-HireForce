import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, Application, ScheduledInterview } from '@/lib/supabase';
import Layout from '@/components/Layout';
import { Card, Button, Input, Textarea, Badge, ScoreRing, Avatar, EmptyState } from '@/components/ui';
import { Upload, FileText, Briefcase, Clock, MapPin, CheckCircle2, XCircle, AlertCircle, User, Plus } from 'lucide-react';
import InterviewView from '@/components/InterviewView';
import ProfileView from '@/components/ProfileView';

export default function CandidateDashboard() {
  const { user, profile } = useAuth();
  const [nav, setNav] = useState('apply');
  const [applications, setApplications] = useState<Application[]>([]);
  const [interviews, setInterviews] = useState<ScheduledInterview[]>([]);
  const [jobPosition, setJobPosition] = useState('');
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [activeInterviewApp, setActiveInterviewApp] = useState<Application | null>(null);

  const loadData = useCallback(async () => {
    if (!user) return;
    const { data: apps } = await supabase
      .from('applications')
      .select('*')
      .eq('candidate_id', user.id)
      .order('created_at', { ascending: false });
    if (apps) setApplications(apps as Application[]);

    const { data: ints } = await supabase
      .from('scheduled_interviews')
      .select('*, applications!inner(*)')
      .eq('candidate_id', user.id)
      .order('scheduled_date', { ascending: true });
    if (ints) setInterviews(ints as ScheduledInterview[]);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  // Real-time: refresh when the candidate's applications or interviews change
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel('candidate-apps')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'applications', filter: `candidate_id=eq.${user.id}` }, () => loadData())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'scheduled_interviews', filter: `candidate_id=eq.${user.id}` }, () => loadData())
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'scheduled_interviews', filter: `candidate_id=eq.${user.id}` }, () => loadData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, loadData]);

  const handleUpload = async () => {
    if (!user || !cvFile || !jobPosition.trim()) return;
    setUploading(true);
    try {
      const ext = cvFile.name.split('.').pop();
      const path = `${user.id}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from('cvs').upload(path, cvFile);
      if (upErr) throw upErr;
      const { data: { publicUrl } } = supabase.storage.from('cvs').getPublicUrl(path);

      const { data: app } = await supabase.from('applications').insert({
        candidate_id: user.id,
        job_position: jobPosition,
        cv_url: publicUrl,
      }).select().single();

      if (app) {
        setApplications((prev) => [app as Application, ...prev]);
        setJobPosition('');
        setCvFile(null);
        setNav('tracking');
      }
    } catch (e) {
      alert('Erreur lors du téléversement: ' + (e as Error).message);
    }
    setUploading(false);
  };

  const startInterview = (app: Application) => {
    setActiveInterviewApp(app);
  };

  const navItems = [
    { id: 'apply', label: 'Postuler', icon: <Plus size={18} /> },
    { id: 'tracking', label: 'Suivi candidatures', icon: <FileText size={18} /> },
    { id: 'interviews', label: 'Entretiens planifiés', icon: <Clock size={18} /> },
    { id: 'profile', label: 'Profil', icon: <User size={18} /> },
  ];

  if (activeInterviewApp) {
    return (
      <InterviewView
        application={activeInterviewApp}
        onComplete={() => { setActiveInterviewApp(null); loadData(); }}
        onExit={() => setActiveInterviewApp(null)}
      />
    );
  }

  return (
    <Layout navItems={navItems} activeNav={nav} onNavChange={setNav}>
      {nav === 'apply' && (
        <div className="max-w-2xl mx-auto">
          <Card className="p-8">
            <div className="text-center mb-8">
              <div className="h-16 w-16 rounded-2xl bg-teal-50 flex items-center justify-center mx-auto mb-4">
                <Briefcase size={28} className="text-teal-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Nouvelle candidature</h2>
              <p className="text-slate-500">Déposez votre CV et indiquez le poste visé pour démarrer le processus.</p>
            </div>

            <div className="space-y-5">
              <Input label="Poste souhaité" value={jobPosition} onChange={setJobPosition} placeholder="Ex: Développeur Full-Stack" required />

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Votre CV (PDF)</label>
                <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer hover:border-teal-500 hover:bg-teal-50/30 transition-all">
                  <div className="flex flex-col items-center gap-2">
                    {cvFile ? (
                      <>
                        <FileText size={28} className="text-teal-600" />
                        <span className="text-sm font-medium text-teal-700">{cvFile.name}</span>
                        <span className="text-xs text-slate-400">Cliquez pour changer</span>
                      </>
                    ) : (
                      <>
                        <Upload size={28} className="text-slate-400" />
                        <span className="text-sm font-medium text-slate-600">Cliquez pour téléverser votre CV</span>
                        <span className="text-xs text-slate-400">Format PDF, max 5MB</span>
                      </>
                    )}
                  </div>
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && setCvFile(e.target.files[0])}
                  />
                </label>
              </div>

              <Button onClick={handleUpload} size="lg" className="w-full" disabled={uploading || !cvFile || !jobPosition.trim()}>
                {uploading ? 'Téléversement...' : 'Soumettre ma candidature'}
              </Button>
            </div>
          </Card>

          {applications.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-slate-700 mb-3">Candidatures récentes</h3>
              <div className="space-y-2">
                {applications.slice(0, 3).map((app) => (
                  <Card key={app.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-800">{app.job_position}</p>
                      <p className="text-xs text-slate-500">{new Date(app.created_at).toLocaleDateString('fr-FR')}</p>
                    </div>
                    <Badge status={app.status} />
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {nav === 'tracking' && (
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-6">Mes candidatures</h2>
          {applications.length === 0 ? (
            <Card className="p-6">
              <EmptyState
                icon={<FileText size={28} />}
                title="Aucune candidature"
                message="Commencez par déposer votre CV pour postuler à un poste."
              />
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {applications.map((app) => (
                <Card key={app.id} className="p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg">{app.job_position}</h3>
                      <p className="text-xs text-slate-500 mt-1">Soumis le {new Date(app.created_at).toLocaleDateString('fr-FR')}</p>
                    </div>
                    <Badge status={app.status} />
                  </div>

                  {app.score !== null && (
                    <div className="flex items-center gap-3 mb-4 p-3 bg-slate-50 rounded-xl">
                      <ScoreRing score={app.score} size={56} />
                      <div>
                        <p className="text-sm font-semibold text-slate-700">Score IA</p>
                        <p className="text-xs text-slate-500">
                          {app.score >= 75 ? 'Excellent profil' : app.score >= 50 ? 'Bon profil' : 'À améliorer'}
                        </p>
                      </div>
                    </div>
                  )}

                  {app.ai_feedback && (
                    <div className="mb-4 p-3 bg-amber-50 border border-amber-100 rounded-xl">
                      <p className="text-xs text-amber-800 leading-relaxed">{app.ai_feedback}</p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    {app.status === 'pending' && (
                      <Button size="sm" onClick={() => startInterview(app)} className="flex-1">
                        Démarrer l'entretien IA
                      </Button>
                    )}
                    {app.status === 'interviewing' && (
                      <Button size="sm" onClick={() => startInterview(app)} className="flex-1">
                        Reprendre l'entretien
                      </Button>
                    )}
                    {app.cv_url && (
                      <Button size="sm" variant="secondary" onClick={() => window.open(app.cv_url!, '_blank')}>
                        Voir CV
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {nav === 'interviews' && (
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-6">Entretiens planifiés</h2>
          {interviews.length === 0 ? (
            <Card className="p-6">
              <EmptyState
                icon={<Clock size={28} />}
                title="Aucun entretien planifié"
                message="Vous serez notifié ici dès qu'un recruteur planifiera un entretien avec vous."
              />
            </Card>
          ) : (
            <div className="space-y-4">
              {interviews.map((iv) => (
                <Card key={iv.id} className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg">{iv.applications?.job_position || 'Entretien'}</h3>
                      <div className="flex items-center gap-2 mt-2 text-sm text-slate-600">
                        <Clock size={16} className="text-teal-600" />
                        {new Date(iv.scheduled_date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}
                      </div>
                      {iv.location && (
                        <div className="flex items-center gap-2 mt-1 text-sm text-slate-600">
                          <MapPin size={16} className="text-teal-600" />
                          {iv.location}
                        </div>
                      )}
                    </div>
                    <div>
                      {iv.status === 'pending' && <Badge status="scheduled" />}
                      {iv.status === 'completed' && <span className="text-xs font-semibold text-emerald-600">Terminé</span>}
                      {iv.status === 'cancelled' && <span className="text-xs font-semibold text-red-600">Annulé</span>}
                    </div>
                  </div>
                  {iv.instructions && (
                    <div className="p-3 bg-slate-50 rounded-xl">
                      <p className="text-xs font-semibold text-slate-700 mb-1">Instructions du recruteur :</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{iv.instructions}</p>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {nav === 'profile' && <ProfileView />}
    </Layout>
  );
}
