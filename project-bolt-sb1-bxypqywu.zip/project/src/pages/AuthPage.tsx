import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Logo, Button, Input } from '@/components/ui';
import { User, Briefcase, Mail, Lock, UserPlus, LogIn } from 'lucide-react';

export default function AuthPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<'candidate' | 'recruiter'>('candidate');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) setError(error);
    } else {
      if (password.length < 6) {
        setError('Le mot de passe doit contenir au moins 6 caractères.');
        setLoading(false);
        return;
      }
      const { error } = await signUp(email, password, fullName, role);
      if (error) setError(error);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left panel - branding */}
      <div className="lg:w-1/2 bg-gradient-to-br from-teal-600 via-cyan-700 to-slate-900 text-white p-8 lg:p-16 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 70% 60%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
        <div className="relative z-10">
          <Logo size="lg" />
        </div>
        <div className="relative z-10 max-w-md">
          <h1 className="text-3xl lg:text-4xl font-extrabold leading-tight mb-4">
            Le recrutement automatisé par l'IA
          </h1>
          <p className="text-teal-100 text-lg leading-relaxed mb-8">
            Parser de CV, entretiens IA, scoring intelligent et planification automatique.
            Gagnez du temps, recrutez les meilleurs talents.
          </p>
          <div className="space-y-3">
            {[
              { icon: '📄', text: 'Agent Parser — lit et analyse les CVs' },
              { icon: '🎤', text: 'Agent Testeur — pose des questions de screening' },
              { icon: '⭐', text: 'Agent Evaluateur — score les candidats' },
              { icon: '📅', text: 'Agent Planificateur — organise les entretiens' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-3 text-teal-50">
                <span className="text-xl">{f.icon}</span>
                <span className="text-sm font-medium">{f.text}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="relative z-10 text-teal-200 text-sm">
          © 2026 SmartRecrut — La plateforme de recrutement nouvelle génération
        </div>
      </div>

      {/* Right panel - form */}
      <div className="lg:w-1/2 flex items-center justify-center p-8 lg:p-16 bg-slate-50">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              {mode === 'login' ? 'Connexion' : 'Créer un compte'}
            </h2>
            <p className="text-slate-500 text-sm">
              {mode === 'login'
                ? 'Connectez-vous à votre espace SmartRecrut'
                : 'Rejoignez la plateforme de recrutement intelligent'}
            </p>
          </div>

          {mode === 'register' && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">Je suis...</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('candidate')}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    role === 'candidate'
                      ? 'border-teal-500 bg-teal-50 text-teal-700'
                      : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <User size={24} />
                  <span className="text-sm font-semibold">Candidat</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('recruiter')}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    role === 'recruiter'
                      ? 'border-teal-500 bg-teal-50 text-teal-700'
                      : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <Briefcase size={24} />
                  <span className="text-sm font-semibold">Recruteur</span>
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <Input label="Nom complet" value={fullName} onChange={setFullName} placeholder="Jean Dupont" required />
            )}
            <Input label="Adresse email" type="email" value={email} onChange={setEmail} placeholder="vous@exemple.com" required />
            <Input label="Mot de passe" type="password" value={password} onChange={setPassword} placeholder="••••••••" required />

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3">
                {error}
              </div>
            )}

            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {mode === 'login' ? (
                <><LogIn size={18} /> {loading ? 'Connexion...' : 'Se connecter'}</>
              ) : (
                <><UserPlus size={18} /> {loading ? 'Création...' : 'Créer mon compte'}</>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-slate-500">
            {mode === 'login' ? (
              <>
                Pas encore de compte ?{' '}
                <button onClick={() => { setMode('register'); setError(null); }} className="text-teal-600 font-semibold hover:underline">
                  S'inscrire
                </button>
              </>
            ) : (
              <>
                Déjà un compte ?{' '}
                <button onClick={() => { setMode('login'); setError(null); }} className="text-teal-600 font-semibold hover:underline">
                  Se connecter
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
