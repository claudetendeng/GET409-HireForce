import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, Application, ScheduledInterview, Profile } from '@/lib/supabase';
import Layout from '@/components/Layout';
import { Card, Button, Input, Textarea, Badge, ScoreRing, Avatar, EmptyState } from '@/components/ui';
import { Users, BarChart3, Calendar, User, Trophy, X, Check, Clock, Mail, TrendingUp, Star } from 'lucide-react';
import ProfileView from '@/components/ProfileView';

export default function RecruiterDashboard() {
  const { user } = useAuth();
  const [nav, setNav] = useState('dashboard');
  const [applications, setApplications] = useState<Application[]>([]);
  const [candidates, setCandidates] = useState<Profile[]>([]);
  const [interviews, setInterviews] = useState<ScheduledInterview[]>([]);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [scheduleModal, setScheduleModal] = useState<Application | null>(null);
  const [filter, setFilter] = useState<string>('all');

  const loadData = useCallback(async () => {
    const { data: apps } = await supabase
      .from('applications')
      .select('*, profiles!inner(*)')
      .order('created_at', { ascending: false });
    if (apps) setApplications(apps as Application[]);

    const { data: cands } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'candidate')
      .order('created_at', { ascending: false });
    if (cands) setCandidates(cands as Profile[]);

    const { data: ints } = await supabase
      .from('scheduled_interviews')
      .select('*, applications!inner(*), profiles!inner(*)')
      .order('scheduled_date', { ascending: true });
    if (ints) setInterviews(ints as ScheduledInterview[]);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Real-time: refresh when any application changes (new candidate applies, status update, etc.)
  useEffect(() => {
    const channel = supabase
      .channel('recruiter-apps')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'applications' }, () => loadData())
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'applications' }, () => loadData())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'scheduled_interviews' }, () => loadData())
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'scheduled_interviews' }, () => loadData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadData]);

  // Auto-evaluate: past recruiter interviews → evaluating
  useEffect(() => {
    const checkPastInterviews = async () => {
      if (!user) return;
      const now = new Date().toISOString();
      const { data: past } = await supabase
        .from('scheduled_interviews')
        .select('application_id')
        .lt('scheduled_date', now)
        .eq('status', 'pending');
      if (past && past.length > 0) {
        for (const p of past) {
          await supabase.from('applications').update({ status: 'evaluating' }).eq('id', p.application_id).eq('status', 'scheduled');
          await supabase.from('scheduled_interviews').update({ status: 'completed' }).eq('application_id', p.application_id).eq('status', 'pending');
        }
        loadData();
      }
    };
    checkPastInterviews();
    const interval = setInterval(checkPastInterviews, 60000);
    return () => clearInterval(interval);
  }, [user, loadData]);

  const refuseCandidate = async (app: Application) => {
    await supabase.from('applications').update({ status: 'refused' }).eq('id', app.id);
    await supabase.from('notifications').insert({
      user_id: app.candidate_id,
      title: 'Candidature refusée',
      message: `Votre candidature pour le poste "${app.job_position}" n'a pas été retenue.`,
      type: 'warning',
    });
    setSelectedApp(null);
    loadData();
  };

  const recruitCandidate = async (app: Application) => {
    await supabase.from('applications').update({ status: 'recruited' }).eq('id', app.id);
    await supabase.from('notifications').insert({
      user_id: app.candidate_id,
      title: 'Félicitations ! Vous êtes recruté',
      message: `Votre candidature pour le poste "${app.job_position}" a été acceptée. Bienvenue dans l'équipe !`,
      type: 'success',
    });
    setSelectedApp(null);
    loadData();
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <BarChart3 size={18} /> },
    { id: 'candidates', label: 'Candidats', icon: <Users size={18} /> },
    { id: 'interviews', label: 'Entretiens planifiés', icon: <Calendar size={18} /> },
    { id: 'profile', label: 'Profil', icon: <User size={18} /> },
  ];

  // Stats
  const stats = {
    total: applications.length,
    evaluating: applications.filter((a) => a.status === 'evaluating').length,
    scheduled: applications.filter((a) => a.status === 'scheduled').length,
    recruited: applications.filter((a) => a.status === 'recruited').length,
    avgScore: applications.filter((a) => a.score !== null).length > 0
      ? Math.round(applications.filter((a) => a.score !== null).reduce((s, a) => s + (a.score || 0), 0) / applications.filter((a) => a.score !== null).length)
      : 0,
  };

  const topCandidates = [...applications]
    .filter((a) => a.score !== null)
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, 5);

  const filteredApps = filter === 'all' ? applications : applications.filter((a) => a.status === filter);

  return (
    <Layout navItems={navItems} activeNav={nav} onNavChange={setNav}>
      {nav === 'dashboard' && (
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Vue d'ensemble</h2>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center">
                  <Users size={20} className="text-blue-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{stats.total}</p>
              <p className="text-sm text-slate-500">Candidatures totales</p>
            </Card>
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-xl bg-amber-50 flex items-center justify-center">
                  <Clock size={20} className="text-amber-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{stats.evaluating}</p>
              <p className="text-sm text-slate-500">En évaluation</p>
            </Card>
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-xl bg-purple-50 flex items-center justify-center">
                  <Calendar size={20} className="text-purple-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{stats.scheduled}</p>
              <p className="text-sm text-slate-500">Entretiens planifiés</p>
            </Card>
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-xl bg-emerald-50 flex items-center justify-center">
                  <Trophy size={20} className="text-emerald-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{stats.recruited}</p>
              <p className="text-sm text-slate-500">Recrutés</p>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <Trophy size={18} className="text-amber-500" /> Top candidats
                </h3>
                <span className="text-xs text-slate-400">Classés par score IA</span>
              </div>
              {topCandidates.length === 0 ? (
                <EmptyState icon={<Star size={28} />} title="Pas encore de scores" message="Les scores apparaîtront après les entretiens IA des candidats." />
              ) : (
                <div className="space-y-3">
                  {topCandidates.map((app, i) => {
                    const cand = candidates.find((c) => c.id === app.candidate_id);
                    return (
                      <div key={app.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 cursor-pointer" onClick={() => { setSelectedApp(app); setNav('candidates'); }}>
                        <div className={`h-8 w-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                          i === 0 ? 'bg-amber-100 text-amber-700' : i === 1 ? 'bg-slate-200 text-slate-700' : i === 2 ? 'bg-orange-100 text-orange-700' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {i + 1}
                        </div>
                        <Avatar url={cand?.avatar_url} name={cand?.full_name || 'C'} size={40} />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-slate-800 truncate">{cand?.full_name || 'Candidat'}</p>
                          <p className="text-xs text-slate-500 truncate">{app.job_position}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <ScoreRing score={app.score} size={48} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>

            <Card className="p-6">
              <h3 className="font-bold text-slate-900 flex items-center gap-2 mb-5">
                <TrendingUp size={18} className="text-teal-600" /> Statistiques
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-slate-600">Score moyen</span>
                    <span className="font-bold text-slate-900">{stats.avgScore}/100</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full" style={{ width: `${stats.avgScore}%` }} />
                  </div>
                </div>
                <div className="pt-3 border-t border-slate-100">
                  <p className="text-sm text-slate-600 mb-2">Taux de conversion</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {stats.total > 0 ? Math.round((stats.recruited / stats.total) * 100) : 0}%
                  </p>
                  <p className="text-xs text-slate-400">Candidats recrutés / total</p>
                </div>
                <div className="pt-3 border-t border-slate-100">
                  <p className="text-sm text-slate-600 mb-2">Candidats en attente d'entretien</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {applications.filter((a) => a.status === 'evaluating' || a.status === 'pending').length}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {nav === 'candidates' && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-900">Candidats</h2>
            <div className="flex gap-2 flex-wrap">
              {['all', 'evaluating', 'scheduled', 'refused', 'recruited'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    filter === f ? 'bg-teal-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {f === 'all' ? 'Tous' : f === 'evaluating' ? 'En évaluation' : f === 'scheduled' ? 'Convoqués' : f === 'refused' ? 'Refusés' : 'Recrutés'}
                </button>
              ))}
            </div>
          </div>

          {filteredApps.length === 0 ? (
            <Card className="p-6">
              <EmptyState icon={<Users size={28} />} title="Aucun candidat" message="Les candidatures apparaîtront ici dès que des candidats postuleront." />
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {filteredApps.map((app) => {
                const cand = candidates.find((c) => c.id === app.candidate_id);
                return (
                  <Card key={app.id} className="p-5 hover:shadow-md transition-shadow">
                    <div className="flex items-start gap-3 mb-4">
                      <Avatar url={cand?.avatar_url} name={cand?.full_name || 'C'} size={48} />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-slate-900 truncate">{cand?.full_name || 'Candidat'}</p>
                        <p className="text-xs text-slate-500 truncate">{app.job_position}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">{new Date(app.created_at).toLocaleDateString('fr-FR')}</p>
                      </div>
                      <Badge status={app.status} />
                    </div>

                    {app.score !== null && (
                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl mb-3">
                        <span className="text-sm font-semibold text-slate-700">Score IA</span>
                        <ScoreRing score={app.score} size={48} />
                      </div>
                    )}

                    {app.ai_feedback && (
                      <div className="mb-3 p-2.5 bg-amber-50 rounded-lg">
                        <p className="text-xs text-amber-800 line-clamp-2">{app.ai_feedback}</p>
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button size="sm" variant="secondary" onClick={() => setSelectedApp(app)} className="flex-1">
                        Détails
                      </Button>
                      {app.status === 'evaluating' && (
                        <Button size="sm" onClick={() => setScheduleModal(app)} className="flex-1">
                          <Calendar size={14} /> Planifier
                        </Button>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {nav === 'interviews' && (
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-6">Entretiens planifiés</h2>
          {interviews.length === 0 ? (
            <Card className="p-6">
              <EmptyState icon={<Calendar size={28} />} title="Aucun entretien planifié" message="Planifiez un entretien depuis la liste des candidats en évaluation." />
            </Card>
          ) : (
            <div className="space-y-4">
              {interviews.map((iv) => {
                const cand = candidates.find((c) => c.id === iv.candidate_id);
                const isPast = new Date(iv.scheduled_date) < new Date();
                return (
                  <Card key={iv.id} className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <Avatar url={cand?.avatar_url} name={cand?.full_name || 'C'} size={48} />
                        <div>
                          <p className="font-bold text-slate-900">{cand?.full_name || 'Candidat'}</p>
                          <p className="text-sm text-slate-500">{iv.applications?.job_position || 'Poste'}</p>
                          <div className="flex items-center gap-2 mt-2 text-sm text-slate-600">
                            <Calendar size={14} className="text-teal-600" />
                            {new Date(iv.scheduled_date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}
                          </div>
                          {iv.instructions && (
                            <p className="text-xs text-slate-500 mt-2 max-w-md">{iv.instructions}</p>
                          )}
                        </div>
                      </div>
                      <div>
                        {iv.status === 'pending' && !isPast && <Badge status="scheduled" />}
                        {iv.status === 'completed' && <span className="text-xs font-semibold text-emerald-600">Terminé</span>}
                        {iv.status === 'cancelled' && <span className="text-xs font-semibold text-red-600">Annulé</span>}
                        {iv.status === 'pending' && isPast && <span className="text-xs font-semibold text-amber-600">En évaluation</span>}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {nav === 'profile' && <ProfileView />}

      {/* Candidate detail modal */}
      {selectedApp && (
        <CandidateDetailModal
          application={selectedApp}
          candidate={candidates.find((c) => c.id === selectedApp.candidate_id) || null}
          onClose={() => setSelectedApp(null)}
          onRefuse={() => refuseCandidate(selectedApp)}
          onRecruit={() => recruitCandidate(selectedApp)}
          onSchedule={() => { setScheduleModal(selectedApp); setSelectedApp(null); }}
        />
      )}

      {/* Schedule modal */}
      {scheduleModal && (
        <ScheduleModal
          application={scheduleModal}
          candidate={candidates.find((c) => c.id === scheduleModal.candidate_id) || null}
          onClose={() => setScheduleModal(null)}
          onScheduled={() => { setScheduleModal(null); loadData(); }}
        />
      )}
    </Layout>
  );
}

function CandidateDetailModal({
  application,
  candidate,
  onClose,
  onRefuse,
  onRecruit,
  onSchedule,
}: {
  application: Application;
  candidate: Profile | null;
  onClose: () => void;
  onRefuse: () => void;
  onRecruit: () => void;
  onSchedule: () => void;
}) {
  const canRecruit = application.status === 'scheduled' || application.status === 'evaluating';
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-3">
            <Avatar url={candidate?.avatar_url} name={candidate?.full_name || 'C'} size={56} />
            <div>
              <h3 className="font-bold text-slate-900 text-lg">{candidate?.full_name || 'Candidat'}</h3>
              <p className="text-sm text-slate-500">{candidate?.email}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 text-slate-400"><X size={20} /></button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
            <div>
              <p className="text-sm font-semibold text-slate-700">Poste visé</p>
              <p className="text-sm text-slate-600">{application.job_position}</p>
            </div>
            <Badge status={application.status} />
          </div>

          {application.score !== null && (
            <div className="flex items-center gap-4 p-4 bg-gradient-to-br from-teal-50 to-cyan-50 rounded-xl">
              <ScoreRing score={application.score} size={72} />
              <div>
                <p className="text-sm font-semibold text-slate-700">Score de l'entretien IA</p>
                <p className="text-xs text-slate-500">
                  {application.score >= 75 ? 'Excellent profil — priorité haute' : application.score >= 50 ? 'Bon profil' : 'Profil à approfondir'}
                </p>
              </div>
            </div>
          )}

          {application.ai_feedback && (
            <div className="p-4 bg-amber-50 border border-amber-100 rounded-xl">
              <p className="text-xs font-semibold text-amber-700 mb-1">Retour de l'IA évaluateur</p>
              <p className="text-sm text-amber-800 leading-relaxed">{application.ai_feedback}</p>
            </div>
          )}

          {application.cv_url && (
            <Button variant="secondary" onClick={() => window.open(application.cv_url!, '_blank')} className="w-full">
              Voir le CV
            </Button>
          )}

          <div className="flex gap-2 pt-2">
            {application.status === 'evaluating' && (
              <Button onClick={onSchedule} className="flex-1">
                <Calendar size={16} /> Planifier un entretien
              </Button>
            )}
            <Button variant="danger" onClick={onRefuse} className="flex-1">
              <X size={16} /> Refuser
            </Button>
            {canRecruit && (
              <Button variant="success" onClick={onRecruit} className="flex-1">
                <Check size={16} /> Recruter
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ScheduleModal({
  application,
  candidate,
  onClose,
  onScheduled,
}: {
  application: Application;
  candidate: Profile | null;
  onClose: () => void;
  onScheduled: () => void;
}) {
  const { user } = useAuth();
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [instructions, setInstructions] = useState('');
  const [scheduling, setScheduling] = useState(false);

  const handleSchedule = async () => {
    if (!user || !date || !time) return;
    setScheduling(true);
    const scheduledDate = new Date(`${date}T${time}`).toISOString();
    try {
      const { error } = await supabase.from('scheduled_interviews').insert({
        application_id: application.id,
        candidate_id: application.candidate_id,
        recruiter_id: user.id,
        scheduled_date: scheduledDate,
        instructions,
        location,
      });
      if (error) throw error;

      await supabase.from('applications').update({ status: 'scheduled' }).eq('id', application.id);

      await supabase.from('notifications').insert({
        user_id: application.candidate_id,
        title: 'Convocation à un entretien',
        message: `Vous êtes convoqué(e) à un entretien pour le poste "${application.job_position}" le ${new Date(scheduledDate).toLocaleString('fr-FR')}.${instructions ? ' Instructions: ' + instructions : ''}`,
        type: 'info',
      });

      onScheduled();
    } catch (e) {
      alert('Erreur: ' + (e as Error).message);
    }
    setScheduling(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-lg w-full p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="font-bold text-slate-900 text-lg">Planifier un entretien</h3>
            <p className="text-sm text-slate-500">{candidate?.full_name} — {application.job_position}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 text-slate-400"><X size={20} /></button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Input label="Date" type="date" value={date} onChange={setDate} required />
            <Input label="Heure" type="time" value={time} onChange={setTime} required />
          </div>
          <Input label="Lieu (optionnel)" value={location} onChange={setLocation} placeholder="Ex: Bureau, Visio, etc." />
          <Textarea label="Instructions / consignes" value={instructions} onChange={setInstructions} placeholder="Préparez une présentation de 5 min, apportez votre portfolio..." rows={4} />

          <div className="p-3 bg-blue-50 rounded-xl flex items-start gap-2">
            <Mail size={16} className="text-blue-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-blue-700">
              Le candidat recevra une notification sur son compte et par email avec ces instructions.
            </p>
          </div>

          <Button onClick={handleSchedule} size="lg" className="w-full" disabled={scheduling || !date || !time}>
            {scheduling ? 'Planification...' : 'Confirmer la convocation'}
          </Button>
        </div>
      </div>
    </div>
  );
}
