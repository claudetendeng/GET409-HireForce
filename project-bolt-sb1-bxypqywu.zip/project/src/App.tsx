import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import AuthPage from '@/pages/AuthPage';
import CandidateDashboard from '@/pages/CandidateDashboard';
import RecruiterDashboard from '@/pages/RecruiterDashboard';
import { Logo } from '@/components/ui';

function AppContent() {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="mb-4 flex justify-center"><Logo size="lg" /></div>
          <div className="h-8 w-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-slate-500 text-sm mt-4">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!user || !profile) return <AuthPage />;

  return profile.role === 'recruiter' ? <RecruiterDashboard /> : <CandidateDashboard />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
