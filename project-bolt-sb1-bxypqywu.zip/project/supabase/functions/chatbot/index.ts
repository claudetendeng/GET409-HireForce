import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { message, role } = await req.json();
    const msg = (message || "").toLowerCase();

    let reply = "";

    if (role === "recruiter") {
      if (msg.includes("score") || msg.includes("évaluer") || msg.includes("evaluer")) {
        reply = "Le score IA est calculé après l'entretien automatique. Il prend en compte la pertinence, la structure et la précision des réponses du candidat. Un score ≥ 75 indique un excellent profil, 50-74 un bon profil, et < 50 un profil à approfondir. Les top scores sont mis en avant sur votre dashboard.";
      } else if (msg.includes("planifier") || msg.includes("entretien") || msg.includes("convocation")) {
        reply = "Pour planifier un entretien : allez dans l'onglet Candidats, sélectionnez un candidat en évaluation, puis cliquez sur 'Planifier'. Le candidat recevra automatiquement une notification avec la date, le lieu et vos instructions. Après la date de l'entretien, le statut passera automatiquement en 'Évaluation'.";
      } else if (msg.includes("refuser") || msg.includes("refus")) {
        reply = "Pour refuser un candidat : ouvrez sa fiche détaillée et cliquez sur 'Refuser'. Le refus est automatique — le candidat est notifié immédiatement sur son compte.";
      } else if (msg.includes("recruter") || msg.includes("recrut")) {
        reply = "Le bouton 'Recruter' n'apparaît que pour les candidats ayant passé un entretien avec vous (statut convoqué ou en évaluation). Une fois recruté, le candidat reçoit une notification de succès.";
      } else if (msg.includes("top") || msg.includes("meilleur")) {
        reply = "Les top candidats sont visibles sur votre dashboard, classés par score IA décroissant. Cliquez sur l'un d'eux pour voir son profil détaillé et planifier un entretien.";
      } else if (msg.includes("bonjour") || msg.includes("salut") || msg.includes("hello")) {
        reply = "Bonjour ! Je suis votre assistant recruteur SmartRecrut. Je peux vous aider à comprendre les scores, planifier des entretiens, refuser ou recruter des candidats. Que souhaitez-vous faire ?";
      } else {
        reply = "En tant que recruteur, vous pouvez : consulter les candidats et leurs scores, planifier des entretiens (le candidat est notifié), refuser un candidat (automatique), ou recruter un candidat ayant passé un entretien. Posez-moi une question sur l'une de ces actions !";
      }
    } else {
      if (msg.includes("entretien") || msg.includes("question")) {
        reply = "L'entretien IA comporte 6 questions sur votre présentation, expérience, compétences, résolution de problèmes, soft skills et motivation. Attention : le copier-coller est désactivé, et si vous quittez la page, l'entretien redémarre. Préparez des exemples concrets !";
      } else if (msg.includes("score") || msg.includes("évaluation")) {
        reply = "Après votre entretien IA, vous recevrez un score sur 100 basé sur la qualité de vos réponses. Le statut passe en 'En évaluation' — le recruteur examinera votre profil et pourra vous convoquer à un entretien ou prendre une décision.";
      } else if (msg.includes("cv") || msg.includes("postuler") || msg.includes("candidature")) {
        reply = "Pour postuler : allez dans l'onglet 'Postuler', indiquez le poste visé et téléversez votre CV en PDF. Ensuite, démarrez l'entretien IA depuis l'onglet 'Suivi candidatures'.";
      } else if (msg.includes("statut") || msg.includes("suivi") || msg.includes("où")) {
        reply = "Les statuts possibles : En attente (CV déposé), Entretien IA (en cours), En évaluation (entretien terminé), Convoqué (entretien planifié par le recruteur), Refusé, ou Recruté. Suivez l'évolution dans l'onglet 'Suivi candidatures'.";
      } else if (msg.includes("convocation") || msg.includes("convoqué")) {
        reply = "Si un recruteur vous convoque, vous recevrez une notification sur votre compte et par email avec la date, le lieu et les instructions. Consultez l'onglet 'Entretiens planifiés' pour les détails.";
      } else if (msg.includes("bonjour") || msg.includes("salut") || msg.includes("hello")) {
        reply = "Bonjour ! Je suis votre assistant SmartRecrut. Je peux vous guider dans votre candidature, expliquer le processus d'entretien IA, et répondre à vos questions sur le recrutement. Comment puis-je vous aider ?";
      } else {
        reply = "Je peux vous aider sur : comment postuler, comment se déroule l'entretien IA, comment sont calculés les scores, suivre vos candidatures, ou comprendre les convocations. Posez-moi votre question !";
      }
    }

    return new Response(JSON.stringify({ reply }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
