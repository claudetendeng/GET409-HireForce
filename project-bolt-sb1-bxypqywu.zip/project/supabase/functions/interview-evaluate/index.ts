import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { jobPosition, questions, answers } = await req.json();

    // Score each answer based on length, specificity, and structure
    const scores: number[] = answers.map((answer: string, i: number) => {
      const length = answer.length;
      const words = answer.trim().split(/\s+/).length;
      const hasStructure = /\b(premièrement|deuxièmement|ensuite|finalement|par exemple|donc|car|cependant)\b/i.test(answer);
      const hasSpecificity = /\b(\d{4}|projet|équipe|résultat|réussite|expérience|mission)\b/i.test(answer);

      let score = 30;
      if (words >= 80) score += 25;
      else if (words >= 50) score += 18;
      else if (words >= 30) score += 10;
      else if (words >= 15) score += 5;

      if (hasStructure) score += 15;
      if (hasSpecificity) score += 15;
      if (length >= 500) score += 10;
      else if (length >= 300) score += 5;

      return Math.min(100, Math.max(20, score));
    });

    const totalScore = Math.round(scores.reduce((s: number, n: number) => s + n, 0) / scores.length);

    const feedbackParts: string[] = [];
    if (totalScore >= 75) {
      feedbackParts.push("Excellent profil ! Vos réponses sont détaillées, structurées et démontrent une réelle maîtrise du sujet.");
    } else if (totalScore >= 50) {
      feedbackParts.push("Bon profil. Vos réponses sont pertinentes mais pourraient gagner en précision et en exemples concrets.");
    } else {
      feedbackParts.push("Profil à approfondir. Vos réponses sont trop courtes ou manquent de structure. Préparez des exemples concrets pour l'entretien.");
    }

    if (scores.some((s: number) => s < 40)) {
      feedbackParts.push("Certaines réponses restent superficielles — approfondissez vos expériences.");
    }
    if (scores.every((s: number) => s >= 70)) {
      feedbackParts.push("Très bonne cohérence sur l'ensemble des questions.");
    }

    feedbackParts.push(`Score global : ${totalScore}/100 pour le poste de ${jobPosition || "ce poste"}.`);

    return new Response(JSON.stringify({
      score: totalScore,
      scores,
      feedback: feedbackParts.join(" "),
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
