import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { jobPosition } = await req.json();

    const questions = [
      {
        id: 1,
        category: "Présentation",
        question: `Bonjour ! Pour commencer, présentez-vous : qui êtes-vous et pourquoi postulez-vous au poste de ${jobPosition || "ce poste"} ?`,
      },
      {
        id: 2,
        category: "Expérience",
        question: `Décrivez en détail une expérience professionnelle ou académique qui vous prépare spécifiquement au poste de ${jobPosition || "ce poste"}.`,
      },
      {
        id: 3,
        category: "Compétences techniques",
        question: `Quelles sont vos trois principales compétences techniques pour ce poste, et comment les avez-vous acquises ?`,
      },
      {
        id: 4,
        category: "Résolution de problèmes",
        question: `Racontez une situation difficile que vous avez rencontrée et expliquez comment vous l'avez résolue. Quelle leçon en avez-vous tirée ?`,
      },
      {
        id: 5,
        category: "Soft skills",
        question: `Comment gérez-vous un désaccord avec un collègue ou un membre de votre équipe ? Donnez un exemple concret.`,
      },
      {
        id: 6,
        category: "Motivation",
        question: `Où vous voyez-vous dans 3 ans, et comment ce poste de ${jobPosition || "ce poste"} s'inscrit-il dans votre projet professionnel ?`,
      },
    ];

    return new Response(JSON.stringify({ questions }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
