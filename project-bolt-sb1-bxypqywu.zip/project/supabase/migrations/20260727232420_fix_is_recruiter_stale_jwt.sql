/*
# Make is_recruiter() robust against stale JWT

## Problem
`is_recruiter()` only reads `auth.jwt() -> 'raw_app_meta_data' -> 'role'`.
If a user's role was updated in the database after login, their JWT still
contains the old role until they log out and back in. This means a recruiter
who was fixed in the DB but hasn't re-logged-in still can't see candidates.

## Fix
Update `is_recruiter()` to ALSO check the `profiles` table directly as a
fallback. Since the function is SECURITY DEFINER, it bypasses RLS and queries
profiles without triggering recursion. This makes it work even with a stale
JWT.
*/

CREATE OR REPLACE FUNCTION is_recruiter()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (auth.jwt() -> 'raw_app_meta_data' ->> 'role') = 'recruiter',
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'recruiter')
  );
$$;
