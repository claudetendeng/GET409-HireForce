/*
# Fix infinite recursion in profiles RLS policy

## Problem
The profiles SELECT policy used `EXISTS (SELECT 1 FROM profiles ...)` to check
if the current user is a recruiter. Since RLS policies on `profiles` are evaluated
when querying `profiles`, this caused infinite recursion (error 42P17).

## Fix
1. Create a `is_recruiter()` SECURITY DEFINER function that reads the role
   directly from `auth.users.raw_app_meta_data` (set at signup) WITHOUT going
   through RLS on `profiles`.
2. Rewrite all policies that previously self-referenced `profiles` to use
   `is_recruiter()` instead.
3. Update the AuthContext to set `raw_app_meta_data` with the role on signup
   so `is_recruiter()` works immediately after registration.

## Functions
- `is_recruiter()` — returns true if the current authenticated user has role
  'recruiter' in their auth metadata.

## Policies updated
- profiles SELECT/INSERT/UPDATE/DELETE
- applications SELECT/INSERT/UPDATE/DELETE
- interview_sessions SELECT/INSERT/UPDATE/DELETE
- scheduled_interviews SELECT/INSERT/UPDATE/DELETE
- notifications INSERT (recruiter can insert for candidates)
*/

-- Helper function: check recruiter role without touching profiles table (avoids recursion)
CREATE OR REPLACE FUNCTION is_recruiter()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (auth.jwt() -> 'raw_app_meta_data' ->> 'role') = 'recruiter',
    false
  );
$$;

-- Fix profiles policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
TO authenticated USING (
  auth.uid() = id OR is_recruiter()
);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_delete_own" ON profiles;
CREATE POLICY "profiles_delete_own" ON profiles FOR DELETE
TO authenticated USING (auth.uid() = id);

-- Fix applications policies (replace self-referencing EXISTS with is_recruiter)
DROP POLICY IF EXISTS "applications_select_candidate" ON applications;
CREATE POLICY "applications_select_candidate" ON applications FOR SELECT
TO authenticated USING (
  auth.uid() = candidate_id OR is_recruiter()
);

DROP POLICY IF EXISTS "applications_insert_candidate" ON applications;
CREATE POLICY "applications_insert_candidate" ON applications FOR INSERT
TO authenticated WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "applications_update" ON applications;
CREATE POLICY "applications_update" ON applications FOR UPDATE
TO authenticated USING (
  auth.uid() = candidate_id OR is_recruiter()
) WITH CHECK (
  auth.uid() = candidate_id OR is_recruiter()
);

DROP POLICY IF EXISTS "applications_delete_candidate" ON applications;
CREATE POLICY "applications_delete_candidate" ON applications FOR DELETE
TO authenticated USING (auth.uid() = candidate_id);

-- Fix interview_sessions policies
DROP POLICY IF EXISTS "interview_sessions_select" ON interview_sessions;
CREATE POLICY "interview_sessions_select" ON interview_sessions FOR SELECT
TO authenticated USING (
  auth.uid() = candidate_id OR is_recruiter()
);

DROP POLICY IF EXISTS "interview_sessions_insert" ON interview_sessions;
CREATE POLICY "interview_sessions_insert" ON interview_sessions FOR INSERT
TO authenticated WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "interview_sessions_update" ON interview_sessions;
CREATE POLICY "interview_sessions_update" ON interview_sessions FOR UPDATE
TO authenticated USING (auth.uid() = candidate_id) WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "interview_sessions_delete" ON interview_sessions;
CREATE POLICY "interview_sessions_delete" ON interview_sessions FOR DELETE
TO authenticated USING (auth.uid() = candidate_id);

-- Fix scheduled_interviews policies
DROP POLICY IF EXISTS "scheduled_interviews_insert" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_insert" ON scheduled_interviews FOR INSERT
TO authenticated WITH CHECK (is_recruiter());

DROP POLICY IF EXISTS "scheduled_interviews_update" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_update" ON scheduled_interviews FOR UPDATE
TO authenticated USING (is_recruiter()) WITH CHECK (is_recruiter());

DROP POLICY IF EXISTS "scheduled_interviews_delete" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_delete" ON scheduled_interviews FOR DELETE
TO authenticated USING (is_recruiter());

-- Fix notifications insert policy (recruiter can insert for candidates)
DROP POLICY IF EXISTS "notifications_insert" ON notifications;
CREATE POLICY "notifications_insert" ON notifications FOR INSERT
TO authenticated WITH CHECK (
  auth.uid() = user_id OR is_recruiter()
);
