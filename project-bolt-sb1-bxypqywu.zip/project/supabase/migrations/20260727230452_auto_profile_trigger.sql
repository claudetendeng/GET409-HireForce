/*
# Auto-create profile on signup

## Summary
Adds a trigger `handle_new_user` that fires AFTER a new row is inserted into
`auth.users`. It creates the corresponding `profiles` row automatically,
using the email from auth.users and the full_name + role from
raw_user_meta_data (set by the client at signup via `options.data`).

This ensures the profile always exists even if the client-side insert fails
or races, and the recruiter role is available immediately via is_recruiter().
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'candidate')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS handle_new_user ON auth.users;
CREATE TRIGGER handle_new_user
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
