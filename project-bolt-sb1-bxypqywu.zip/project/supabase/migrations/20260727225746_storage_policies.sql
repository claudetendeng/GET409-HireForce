/*
# Storage policies for CVs and Avatars

## Summary
Adds public read + authenticated write policies for the `cvs` and `avatars` storage buckets so candidates can upload their CV and both roles can upload profile photos.

## Policies
- cvs: anyone can read (public CVs for recruiters); authenticated can upload/update their own folder
- avatars: anyone can read; authenticated can upload/update their own folder
*/

-- Public read for cvs bucket
DROP POLICY IF EXISTS "cvs_public_read" ON storage.objects;
CREATE POLICY "cvs_public_read" ON storage.objects FOR SELECT
TO anon, authenticated USING (bucket_id = 'cvs');

DROP POLICY IF EXISTS "cvs_authed_write" ON storage.objects;
CREATE POLICY "cvs_authed_write" ON storage.objects FOR INSERT
TO authenticated WITH CHECK (bucket_id = 'cvs');

DROP POLICY IF EXISTS "cvs_authed_update" ON storage.objects;
CREATE POLICY "cvs_authed_update" ON storage.objects FOR UPDATE
TO authenticated USING (bucket_id = 'cvs') WITH CHECK (bucket_id = 'cvs');

-- Public read for avatars bucket
DROP POLICY IF EXISTS "avatars_public_read" ON storage.objects;
CREATE POLICY "avatars_public_read" ON storage.objects FOR SELECT
TO anon, authenticated USING (bucket_id = 'avatars');

DROP POLICY IF EXISTS "avatars_authed_write" ON storage.objects;
CREATE POLICY "avatars_authed_write" ON storage.objects FOR INSERT
TO authenticated WITH CHECK (bucket_id = 'avatars');

DROP POLICY IF EXISTS "avatars_authed_update" ON storage.objects;
CREATE POLICY "avatars_authed_update" ON storage.objects FOR UPDATE
TO authenticated USING (bucket_id = 'avatars') WITH CHECK (bucket_id = 'avatars');
