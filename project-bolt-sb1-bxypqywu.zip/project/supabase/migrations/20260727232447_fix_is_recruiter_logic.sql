/*
# Fix is_recruiter() logic bug

## Problem
The previous is_recruiter() used COALESCE, but COALESCE only replaces NULL,
not FALSE. When the JWT role was 'candidate', the expression
`(jwt -> 'raw_app_meta_data' ->> 'role') = 'recruiter'` evaluates to FALSE
(not NULL), so COALESCE returned FALSE and never checked the profiles table.

## Fix
Use a simple OR: if the JWT says recruiter OR the profiles table says
recruiter, return true.
*/

CREATE OR REPLACE FUNCTION is_recruiter()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    (auth.jwt() -> 'raw_app_meta_data' ->> 'role') = 'recruiter'
    OR
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'recruiter')
$$;
