/*
# Sync role to app metadata via trigger

## Problem
`is_recruiter()` reads from `auth.jwt() -> 'raw_app_meta_data' -> 'role'`, but
`supabase.auth.signUp({ options: { data: { role } } })` writes to
`raw_user_meta_data`, NOT `raw_app_meta_data`. So `is_recruiter()` returns
false for newly registered recruiters until an admin manually updates
`raw_app_meta_data`.

## Fix
Create a trigger `sync_role_to_app_meta` that fires AFTER INSERT on
`auth.users` and copies `role` (and `full_name`) from `raw_user_meta_data`
into `raw_app_meta_data`. This makes `is_recruiter()` work immediately
after signup, with no admin action required.

## Function
- `sync_role_to_app_meta()` — SECURITY DEFINER trigger function that merges
  the new user's `raw_user_meta_data` into `raw_app_meta_data`.
*/

CREATE OR REPLACE FUNCTION public.sync_role_to_app_meta()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public
AS $$
BEGIN
  -- Copy role + full_name from user_meta_data into app_meta_data so RLS can read it
  IF NEW.raw_user_meta_data IS NOT NULL THEN
    NEW.raw_app_meta_data = COALESCE(NEW.raw_app_meta_data, '{}'::jsonb)
      || jsonb_build_object(
        'role', NEW.raw_user_meta_data->'role',
        'full_name', NEW.raw_user_meta_data->'full_name'
      );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_role_to_app_meta ON auth.users;
CREATE TRIGGER sync_role_to_app_meta
  BEFORE INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.sync_role_to_app_meta();
