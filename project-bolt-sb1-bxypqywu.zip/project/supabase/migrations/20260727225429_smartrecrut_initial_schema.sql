/*
# SmartRecrut Initial Schema

## Summary
Creates the full data model for the SmartRecrut AI recruitment platform.

## Tables
1. `profiles` - Extended user data (name, avatar, role) linked to auth.users
2. `applications` - Candidate job applications with CV, position, status, and AI score
3. `interview_sessions` - AI interview sessions with Q&A and anti-cheat tracking
4. `scheduled_interviews` - Recruiter-planned interviews with date and instructions
5. `notifications` - In-app notifications for candidates and recruiters
6. `chat_messages` - Chatbot conversation history per user

## Status Values
- applications.status: 'pending' | 'interviewing' | 'evaluating' | 'scheduled' | 'refused' | 'recruited'

## Security
- RLS enabled on all tables
- Profiles: users read/update own profile; recruiters can read all candidate profiles
- Applications: candidates manage own; recruiters can read all + update status/score
- Interview sessions: candidates own; recruiters can read
- Scheduled interviews: recruiters create/update; candidates read own
- Notifications: each user reads own; system inserts via service role
- Chat messages: each user reads/writes own
*/

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  avatar_url text,
  role text NOT NULL DEFAULT 'candidate' CHECK (role IN ('candidate', 'recruiter')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
TO authenticated USING (
  auth.uid() = id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_delete_own" ON profiles;
CREATE POLICY "profiles_delete_own" ON profiles FOR DELETE
TO authenticated USING (auth.uid() = id);

-- Applications table
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  job_position text NOT NULL,
  cv_url text,
  cv_text text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','interviewing','evaluating','scheduled','refused','recruited')),
  score integer DEFAULT NULL,
  ai_feedback text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS applications_candidate_idx ON applications(candidate_id);
CREATE INDEX IF NOT EXISTS applications_status_idx ON applications(status);

DROP POLICY IF EXISTS "applications_select_candidate" ON applications;
CREATE POLICY "applications_select_candidate" ON applications FOR SELECT
TO authenticated USING (
  auth.uid() = candidate_id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "applications_insert_candidate" ON applications;
CREATE POLICY "applications_insert_candidate" ON applications FOR INSERT
TO authenticated WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "applications_update" ON applications;
CREATE POLICY "applications_update" ON applications FOR UPDATE
TO authenticated USING (
  auth.uid() = candidate_id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
) WITH CHECK (
  auth.uid() = candidate_id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "applications_delete_candidate" ON applications;
CREATE POLICY "applications_delete_candidate" ON applications FOR DELETE
TO authenticated USING (auth.uid() = candidate_id);

-- Interview sessions
CREATE TABLE IF NOT EXISTS interview_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  candidate_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  questions jsonb NOT NULL DEFAULT '[]',
  answers jsonb NOT NULL DEFAULT '[]',
  scores jsonb NOT NULL DEFAULT '[]',
  total_score integer DEFAULT NULL,
  completed boolean NOT NULL DEFAULT false,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz DEFAULT NULL,
  restart_count integer NOT NULL DEFAULT 0
);

ALTER TABLE interview_sessions ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS interview_sessions_app_idx ON interview_sessions(application_id);

DROP POLICY IF EXISTS "interview_sessions_select" ON interview_sessions;
CREATE POLICY "interview_sessions_select" ON interview_sessions FOR SELECT
TO authenticated USING (
  auth.uid() = candidate_id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "interview_sessions_insert" ON interview_sessions;
CREATE POLICY "interview_sessions_insert" ON interview_sessions FOR INSERT
TO authenticated WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "interview_sessions_update" ON interview_sessions;
CREATE POLICY "interview_sessions_update" ON interview_sessions FOR UPDATE
TO authenticated USING (auth.uid() = candidate_id) WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "interview_sessions_delete" ON interview_sessions;
CREATE POLICY "interview_sessions_delete" ON interview_sessions FOR DELETE
TO authenticated USING (auth.uid() = candidate_id);

-- Scheduled interviews (recruiter plans)
CREATE TABLE IF NOT EXISTS scheduled_interviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  candidate_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recruiter_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  scheduled_date timestamptz NOT NULL,
  instructions text NOT NULL DEFAULT '',
  location text DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','cancelled')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE scheduled_interviews ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS scheduled_interviews_app_idx ON scheduled_interviews(application_id);
CREATE INDEX IF NOT EXISTS scheduled_interviews_candidate_idx ON scheduled_interviews(candidate_id);

DROP POLICY IF EXISTS "scheduled_interviews_select" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_select" ON scheduled_interviews FOR SELECT
TO authenticated USING (
  auth.uid() = candidate_id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "scheduled_interviews_insert" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_insert" ON scheduled_interviews FOR INSERT
TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "scheduled_interviews_update" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_update" ON scheduled_interviews FOR UPDATE
TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
) WITH CHECK (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "scheduled_interviews_delete" ON scheduled_interviews;
CREATE POLICY "scheduled_interviews_delete" ON scheduled_interviews FOR DELETE
TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info' CHECK (type IN ('info','success','warning','error')),
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications(user_id);

DROP POLICY IF EXISTS "notifications_select_own" ON notifications;
CREATE POLICY "notifications_select_own" ON notifications FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "notifications_insert" ON notifications;
CREATE POLICY "notifications_insert" ON notifications FOR INSERT
TO authenticated WITH CHECK (
  auth.uid() = user_id OR
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'recruiter')
);

DROP POLICY IF EXISTS "notifications_update_own" ON notifications;
CREATE POLICY "notifications_update_own" ON notifications FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "notifications_delete_own" ON notifications;
CREATE POLICY "notifications_delete_own" ON notifications FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user','assistant')),
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS chat_messages_user_idx ON chat_messages(user_id);

DROP POLICY IF EXISTS "chat_messages_select_own" ON chat_messages;
CREATE POLICY "chat_messages_select_own" ON chat_messages FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "chat_messages_insert_own" ON chat_messages;
CREATE POLICY "chat_messages_insert_own" ON chat_messages FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "chat_messages_update_own" ON chat_messages;
CREATE POLICY "chat_messages_update_own" ON chat_messages FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "chat_messages_delete_own" ON chat_messages;
CREATE POLICY "chat_messages_delete_own" ON chat_messages FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- Function to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS applications_updated_at ON applications;
CREATE TRIGGER applications_updated_at
  BEFORE UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
